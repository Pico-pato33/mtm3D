# Web de venta de piezas impresas en 3D: diseño

Fecha: 2026-11-08

## Objetivo

Una web para que la gente vea piezas impresas en 3D, marque las que le interesan y envíe un pedido. Las piezas se imprimen bajo pedido. El dueño ve lo que ha elegido cada cliente y cierra el pedido por WhatsApp.

## Restricciones

- Presupuesto: lo mínimo posible o gratis. El dominio propio es opcional (unos 10 €/año).
- Sin pago online al inicio. El cobro es manual (Bizum o transferencia) tras confirmar por WhatsApp.
- Los modelos proceden de Printables, Thingiverse y MakerWorld. Solo se publican modelos con licencia que permita uso comercial.
- Prioridad al móvil: la mayoría de clientes llegará desde WhatsApp o Instagram.

## Enfoque elegido

Web estática alojada gratis (GitHub Pages o Cloudflare Pages) más una hoja de Google Sheets con dos pestañas, `Catálogo` y `Pedidos`, que hace de base de datos y de panel. Un Apps Script gratuito recibe los pedidos y los añade a la hoja.

Descartado: plataformas de tienda (planes útiles de pago, el plan gratuito de Ecwid limita los productos) y Notion/Forms (mala experiencia para marcar piezas).

## Estructura de la página

Una sola página con:

- Cabecera con el nombre de la tienda y el botón "Mi selección" con contador.
- Catálogo en cuadrícula con buscador y filtro por categoría.
- Ficha de pieza (modal): fotos, descripción, tamaño, colores y botón "Añadir a mi selección".
- Panel "Mi selección": cantidad y color por pieza, nombre, contacto, notas y botón "Enviar pedido".
- Pie: cómo funciona el pedido, créditos a los autores originales y aviso de privacidad.

## Datos

### Pestaña `Catálogo`

Una fila por pieza. Columnas: `id`, `nombre`, `categoría`, `fotos` (URLs de fotos propias), `descripción`, `tamaño`, `colores` (lista), `precio` (cifra o "a consultar"), `autor`, `licencia`, `enlace_original`, `activa` (sí/no).

La web lee esta pestaña publicada como CSV. Las piezas con `activa = no` no se muestran.

### Pestaña `Pedidos`

Una fila por pedido. Columnas: `número`, `fecha`, `nombre`, `contacto`, `piezas` (texto con cantidad y color de cada una), `notas`, `estado`.

`estado` se cambia a mano con un desplegable: nuevo, confirmado, imprimiendo, listo, entregado, cancelado.

## Flujo del pedido

1. El cliente añade piezas a "Mi selección" y ajusta cantidad y color.
2. Rellena nombre y contacto (teléfono o Instagram) y, si quiere, notas.
3. Pulsa "Enviar pedido". A la vez:
   - la web envía el pedido al Apps Script, que añade una fila a `Pedidos` con estado "nuevo";
   - se abre WhatsApp con un mensaje ya escrito con el resumen, dirigido al número del dueño.
4. La web muestra una confirmación con el número de pedido.

El número de WhatsApp y la URL del Apps Script se guardan en un único archivo de configuración.

## Licencias y créditos

- Solo se publican piezas con licencia que permita uso comercial (por ejemplo CC0, CC BY, CC BY-SA, o modelos de Printables marcados para uso comercial). Se excluyen las licencias no comerciales (CC BY-NC y similares).
- Cada pieza muestra el autor y un enlace al modelo original.
- Las fotos son del propio dueño, no del autor del modelo.
- La web no aloja ni distribuye los archivos STL.

## Errores y casos límite

- Si el guardado en la hoja falla, la web abre WhatsApp igualmente y avisa al cliente de que envíe el mensaje. El mensaje es la copia de seguridad.
- Si el catálogo no carga, se muestra un mensaje claro en lugar de una página vacía.
- La selección se guarda en el navegador del cliente para que no se pierda al cerrar la pestaña.
- Se valida que nombre y contacto estén rellenos antes de enviar.
- Un campo oculto en el formulario frena los envíos automáticos de bots.

## Privacidad

Solo se piden nombre y contacto. El pie incluye un aviso corto que explica para qué se usan y que solo los ve el dueño.

## Pruebas

- Pedido de prueba completo de principio a fin contra una hoja de pruebas separada de la real.
- Catálogo vacío, con una pieza y con muchas.
- Nombres y notas con tildes, ñ y emojis.
- Comprobación en un móvil real y en un ordenador.
- Fallo simulado del Apps Script para comprobar que se abre WhatsApp igualmente.

## Fuera de alcance (por ahora)

Pago online, cuentas de usuario, panel de administración propio (la hoja de Google es el panel), cálculo automático de envío e idiomas distintos del español.

## Datos que aporta el dueño antes de construir

Ya definidos: nombre de la tienda (mtm_3D, que en direcciones web se escribe sin guion bajo, por ejemplo mtm3d) y número de WhatsApp (+34 613522509).

Pendiente de aportar por el dueño: la lista inicial de piezas con sus fotos y la licencia de cada modelo.
