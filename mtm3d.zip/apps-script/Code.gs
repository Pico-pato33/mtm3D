// Recibe los pedidos de la web y los añade a la pestaña "Pedidos".
// Desplegar como aplicación web: ejecutar como el dueño, acceso "Cualquier persona".

var MAX_FIELD = 1000;

// Texto seguro para una celda: recorta, limita la longitud y evita que la hoja lo lea como fórmula.
function cleanText_(value) {
  var text = String(value == null ? "" : value).trim().slice(0, MAX_FIELD);
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}

// Devuelve la fila a guardar o null si el pedido no es válido. No usa APIs de Google (se prueba en Node).
function buildRow(payload) {
  if (!payload || typeof payload !== "object") return null;
  if (String(payload.website || "").trim() !== "") return null; // campo señuelo: solo lo rellenan los bots
  var nombre = cleanText_(payload.nombre);
  var contacto = cleanText_(payload.contacto);
  var piezas = cleanText_(payload.piezas);
  if (!nombre || !contacto || !piezas) return null;
  return [
    cleanText_(payload.numero),
    cleanText_(payload.fecha),
    nombre,
    contacto,
    piezas,
    cleanText_(payload.notas),
    "nuevo",
  ];
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    var row = buildRow(JSON.parse(e.postData.contents));
    if (!row) return json_({ ok: false });
    lock.waitLock(10000);
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Pedidos").appendRow(row);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false });
  } finally {
    try {
      lock.releaseLock();
    } catch (err2) {}
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
