import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";

// Code.gs usa APIs de Google solo dentro de doPost; buildRow es una función pura.
const ctx = vm.createContext({});
vm.runInContext(readFileSync(new URL("../apps-script/Code.gs", import.meta.url), "utf8"), ctx);
const buildRow = (payload) => JSON.parse(JSON.stringify(ctx.buildRow(payload)));

const valido = {
  numero: "MTM-261108-ABCD",
  fecha: "2026-11-08T19:15:00.000Z",
  nombre: "Ana",
  contacto: "600000000",
  piezas: "2x Soporte (negro)",
  notas: "Para regalo",
  website: "",
};

test("devuelve la fila con estado nuevo para un pedido válido", () => {
  assert.deepEqual(buildRow(valido), [
    "MTM-261108-ABCD", "2026-11-08T19:15:00.000Z", "Ana", "600000000",
    "2x Soporte (negro)", "Para regalo", "nuevo",
  ]);
});

test("devuelve null si falta nombre, contacto o piezas", () => {
  for (const campo of ["nombre", "contacto", "piezas"]) {
    assert.equal(buildRow({ ...valido, [campo]: "  " }), null, campo);
    assert.equal(buildRow({ ...valido, [campo]: undefined }), null, campo);
  }
  assert.equal(buildRow(null), null);
});

test("devuelve null si el campo website no está vacío", () => {
  assert.equal(buildRow({ ...valido, website: "http://spam.example" }), null);
});

test("un texto que empieza por =, +, - o @ se guarda con un apóstrofo delante", () => {
  for (const peligro of ["=1+1", "+34600", "-2+3", "@SUMA(A1)"]) {
    const row = buildRow({ ...valido, nombre: peligro, notas: peligro });
    assert.equal(row[2], "'" + peligro);
    assert.equal(row[5], "'" + peligro);
  }
  assert.equal(buildRow(valido)[2], "Ana");
});

test("limita cada campo a 1000 caracteres", () => {
  const row = buildRow({ ...valido, notas: "x".repeat(5000) });
  assert.equal(row[5].length, 1000);
});

test("conserva emojis, ñ y tildes", () => {
  const row = buildRow({ ...valido, nombre: "Álvaro Muñoz 🙂", notas: "¡Gracias! 🎉" });
  assert.equal(row[2], "Álvaro Muñoz 🙂");
  assert.equal(row[5], "¡Gracias! 🎉");
});
