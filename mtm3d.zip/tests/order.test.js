import { test } from "node:test";
import assert from "node:assert/strict";
import {
  validateCustomer,
  generateOrderNumber,
  formatPieces,
  buildOrder,
  buildWhatsAppUrl,
  submitToSheet,
} from "../js/order.js";

const items = [
  { id: "1", nombre: "Soporte", qty: 2, color: "negro" },
  { id: "2", nombre: "Llavero", qty: 1, color: "" },
];
const now = new Date(2026, 10, 8, 20, 15);

test("validateCustomer falla con nombre o contacto vacíos o solo espacios, con mensajes en español", () => {
  const r = validateCustomer({ nombre: "  ", contacto: "" });
  assert.equal(r.ok, false);
  assert.match(r.errors.nombre, /nombre/i);
  assert.match(r.errors.contacto, /contacto/i);
  assert.deepEqual(validateCustomer({ nombre: "Ana", contacto: "600000000" }), { ok: true, errors: {} });
});

test("generateOrderNumber con 2026-11-08 devuelve MTM-261108- seguido de 4 caracteres válidos", () => {
  const n = generateOrderNumber(now, () => 0.5);
  assert.match(n, /^MTM-261108-[A-Z0-9]{4}$/);
  assert.notEqual(generateOrderNumber(now, () => 0.1), generateOrderNumber(now, () => 0.9));
});

test("formatPieces devuelve el texto con cantidad y color, sin paréntesis si no hay color", () => {
  assert.equal(formatPieces(items), "2x Soporte (negro); 1x Llavero");
});

test("buildOrder recorta espacios, pone fecha ISO y notas vacías si no hay", () => {
  const o = buildOrder({
    numero: "MTM-261108-ABCD",
    items,
    customer: { nombre: "  Ana ", contacto: " 600000000 " },
    now,
  });
  assert.equal(o.nombre, "Ana");
  assert.equal(o.contacto, "600000000");
  assert.equal(o.notas, "");
  assert.equal(o.fecha, now.toISOString());
  assert.equal(o.piezas, "2x Soporte (negro); 1x Llavero");
  assert.equal(o.numero, "MTM-261108-ABCD");
});

test("buildWhatsAppUrl usa solo los dígitos del número y empieza por https://wa.me/34613522509?text=", () => {
  const o = buildOrder({ numero: "MTM-1", items, customer: { nombre: "Ana", contacto: "1" }, now });
  assert.ok(buildWhatsAppUrl("+34 613 52 25 09", o).startsWith("https://wa.me/34613522509?text="));
});

test("el texto decodificado del enlace contiene número de pedido, nombre y piezas, con emojis, ñ y tildes intactos", () => {
  const o = buildOrder({
    numero: "MTM-261108-ABCD",
    items: [{ id: "1", nombre: "Soporte de móvil 🎉", qty: 2, color: "negro" }],
    customer: { nombre: "Álvaro Muñoz 🙂", contacto: "600000000", notas: "Para el cumple & más" },
    now,
  });
  const text = decodeURIComponent(buildWhatsAppUrl("34613522509", o).split("?text=")[1]);
  assert.match(text, /Hola, soy Álvaro Muñoz 🙂\. Quiero hacer el pedido MTM-261108-ABCD:/);
  assert.match(text, /- 2x Soporte de móvil 🎉 \(negro\)/);
  assert.match(text, /Notas: Para el cumple & más/);
});

test("sin notas, el mensaje no incluye la línea Notas", () => {
  const o = buildOrder({ numero: "MTM-1", items, customer: { nombre: "Ana", contacto: "1" }, now });
  const text = decodeURIComponent(buildWhatsAppUrl("34613522509", o).split("?text=")[1]);
  assert.doesNotMatch(text, /Notas:/);
});

test("un pedido de 30 piezas distintas sigue generando un enlace válido", () => {
  const many = Array.from({ length: 30 }, (_, i) => ({
    id: String(i), nombre: `Pieza número ${i} ñandú`, qty: 1, color: "rojo",
  }));
  const o = buildOrder({ numero: "MTM-1", items: many, customer: { nombre: "Ana", contacto: "1" }, now });
  const url = buildWhatsAppUrl("34613522509", o);
  const text = decodeURIComponent(url.split("?text=")[1]);
  assert.equal(text.split("\n").filter((l) => l.startsWith("- ")).length, 30);
});

// ---- Correcciones de la revisión final ----

const fakeFetch = (res) => async () => res;
const okRes = (body, ok = true) => ({ ok, json: async () => body });

test("submitToSheet devuelve true solo si la respuesta es ok y el script contesta {ok:true}", async () => {
  assert.equal(await submitToSheet("https://x/exec", { a: 1 }, fakeFetch(okRes({ ok: true }))), true);
});

test("submitToSheet devuelve false si el script contesta {ok:false}, la respuesta no es ok, el JSON es inválido o fetch falla", async () => {
  assert.equal(await submitToSheet("https://x/exec", {}, fakeFetch(okRes({ ok: false }))), false);
  assert.equal(await submitToSheet("https://x/exec", {}, fakeFetch(okRes({ ok: true }, false))), false);
  assert.equal(
    await submitToSheet("https://x/exec", {}, fakeFetch({ ok: true, json: async () => { throw new Error("no json"); } })),
    false,
  );
  assert.equal(await submitToSheet("https://x/exec", {}, async () => { throw new Error("red"); }), false);
});

test("submitToSheet devuelve false sin llamar a fetch si no hay endpoint", async () => {
  let llamadas = 0;
  assert.equal(await submitToSheet("", {}, async () => { llamadas++; return okRes({ ok: true }); }), false);
  assert.equal(llamadas, 0);
});

test("submitToSheet envía el pedido como JSON en text/plain por POST", async () => {
  let visto;
  await submitToSheet("https://x/exec", { numero: "MTM-1" }, async (url, opts) => {
    visto = { url, method: opts.method, type: opts.headers["Content-Type"], body: opts.body };
    return okRes({ ok: true });
  });
  assert.equal(visto.method, "POST");
  assert.match(visto.type, /^text\/plain/);
  assert.deepEqual(JSON.parse(visto.body), { numero: "MTM-1" });
});

test("buildWhatsAppUrl no lanza error con un emoji partido a la mitad", () => {
  const o = buildOrder({
    numero: "MTM-1", items, customer: { nombre: "Ana \uD83D", contacto: "1" }, now,
  });
  const url = buildWhatsAppUrl("34613522509", o);
  assert.match(decodeURIComponent(url.split("?text=")[1]), /Hola, soy Ana �\./);
});
