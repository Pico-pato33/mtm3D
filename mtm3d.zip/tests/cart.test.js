import { test } from "node:test";
import assert from "node:assert/strict";
import { createCart } from "../js/cart.js";

function fakeStorage(initial = {}) {
  const data = { ...initial };
  return {
    data,
    getItem: (k) => (k in data ? data[k] : null),
    setItem: (k, v) => {
      data[k] = v;
    },
  };
}

const soporte = { id: "1", nombre: "Soporte", colores: ["negro", "rojo"] };
const llavero = { id: "2", nombre: "Llavero", colores: [] };

test("add añade la pieza con cantidad 1 y su primer color; añadirla otra vez suma 1", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  assert.deepEqual(cart.items(), [{ id: "1", nombre: "Soporte", qty: 1, color: "negro" }]);
  cart.add(soporte);
  assert.equal(cart.items()[0].qty, 2);
});

test("add deja color vacío si la pieza no tiene colores", () => {
  const cart = createCart(fakeStorage());
  cart.add(llavero);
  assert.equal(cart.items()[0].color, "");
});

test("setQty acepta enteros de 1 a 99, redondea hacia abajo los decimales y limita a 99", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.setQty("1", 5);
  assert.equal(cart.items()[0].qty, 5);
  cart.setQty("1", 3.9);
  assert.equal(cart.items()[0].qty, 3);
  cart.setQty("1", "7");
  assert.equal(cart.items()[0].qty, 7);
  cart.setQty("1", 5000);
  assert.equal(cart.items()[0].qty, 99);
});

test("setQty con 0 o negativo elimina la pieza", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.setQty("1", 0);
  assert.deepEqual(cart.items(), []);
  cart.add(soporte);
  cart.setQty("1", -4);
  assert.deepEqual(cart.items(), []);
});

test("setQty con NaN, vacío o texto no cambia nada", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.setQty("1", 4);
  for (const bad of [NaN, "", "abc", undefined, null]) cart.setQty("1", bad);
  assert.equal(cart.items()[0].qty, 4);
});

test("count suma cantidades", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.add(llavero);
  cart.setQty("1", 3);
  assert.equal(cart.count(), 4);
});

test("setColor, remove y clear funcionan", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.add(llavero);
  cart.setColor("1", "rojo");
  assert.equal(cart.items()[0].color, "rojo");
  cart.remove("2");
  assert.deepEqual(cart.items().map((i) => i.id), ["1"]);
  cart.clear();
  assert.deepEqual(cart.items(), []);
});

test("pruneTo elimina las piezas cuyo id ya no está en la lista", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.add(llavero);
  cart.pruneTo(["2"]);
  assert.deepEqual(cart.items().map((i) => i.id), ["2"]);
});

test("los cambios se guardan en storage y un cart nuevo con el mismo storage los recupera", () => {
  const storage = fakeStorage();
  const a = createCart(storage);
  a.add(soporte);
  a.setQty("1", 3);
  const b = createCart(storage);
  assert.deepEqual(b.items(), [{ id: "1", nombre: "Soporte", qty: 3, color: "negro" }]);
});

test("con JSON corrupto en storage, items() devuelve []", () => {
  const cart = createCart(fakeStorage({ "mtm3d.cart": "{no es json" }));
  assert.deepEqual(cart.items(), []);
  const cart2 = createCart(fakeStorage({ "mtm3d.cart": '{"a":1}' }));
  assert.deepEqual(cart2.items(), []);
});

test("con storage null o con setItem que lanza error, el cart sigue funcionando en memoria", () => {
  const sinStorage = createCart(null);
  sinStorage.add(soporte);
  assert.equal(sinStorage.count(), 1);

  const roto = createCart({
    getItem: () => {
      throw new Error("bloqueado");
    },
    setItem: () => {
      throw new Error("lleno");
    },
  });
  roto.add(soporte);
  assert.equal(roto.count(), 1);
});

test("normalizeColors cambia al primer color disponible si el guardado ya no existe", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.setColor("1", "rojo");
  cart.normalizeColors([{ id: "1", colores: ["negro"] }]);
  assert.equal(cart.items()[0].color, "negro");
});

test("normalizeColors respeta el color guardado si sigue disponible y deja vacío si la pieza ya no tiene colores", () => {
  const cart = createCart(fakeStorage());
  cart.add(soporte);
  cart.add(llavero);
  cart.setColor("1", "rojo");
  cart.normalizeColors([
    { id: "1", colores: ["negro", "rojo"] },
    { id: "2", colores: [] },
  ]);
  assert.equal(cart.items()[0].color, "rojo");
  cart.setColor("2", "verde");
  cart.normalizeColors([{ id: "1", colores: ["negro", "rojo"] }, { id: "2", colores: [] }]);
  assert.equal(cart.items()[1].color, "");
});
