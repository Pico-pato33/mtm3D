import { test } from "node:test";
import assert from "node:assert/strict";
import { parseCsv, parseCatalogCsv, filterPieces, categoriesOf } from "../js/catalog.js";

const HEADER =
  "id,nombre,categoría,fotos,descripción,tamaño,colores,precio,autor,licencia,enlace_original,activa";

function row(o) {
  const d = {
    id: "1", nombre: "Pieza", categoria: "Hogar", fotos: "", descripcion: "",
    tamano: "", colores: "", precio: "", autor: "", licencia: "", enlace: "", activa: "sí",
    ...o,
  };
  return [d.id, d.nombre, d.categoria, d.fotos, d.descripcion, d.tamano, d.colores,
    d.precio, d.autor, d.licencia, d.enlace, d.activa].join(",");
}

test("parseCsv lee comas, comillas dobles escapadas y saltos de línea dentro de comillas", () => {
  assert.deepEqual(parseCsv('a,"b, ""c""\nd",e'), [["a", 'b, "c"\nd', "e"]]);
});

test("parseCatalogCsv ignora piezas con activa = no y acepta sí y si como activas", () => {
  const csv = [HEADER, row({ id: "1", activa: "sí" }), row({ id: "2", activa: "si" }),
    row({ id: "3", activa: "no" })].join("\n");
  assert.deepEqual(parseCatalogCsv(csv).map((p) => p.id), ["1", "2"]);
});

test("parseCatalogCsv separa fotos y colores por | y devuelve [] si están vacíos", () => {
  const csv = [HEADER, row({ id: "1", fotos: "a.jpg|b.jpg", colores: "negro|rojo" }),
    row({ id: "2" })].join("\n");
  const [p1, p2] = parseCatalogCsv(csv);
  assert.deepEqual(p1.fotos, ["a.jpg", "b.jpg"]);
  assert.deepEqual(p1.colores, ["negro", "rojo"]);
  assert.deepEqual(p2.fotos, []);
  assert.deepEqual(p2.colores, []);
});

test("parseCatalogCsv reconoce cabeceras con tildes", () => {
  const csv = [HEADER, row({ categoria: "Hogar", descripcion: "Desc", tamano: "5 cm" })].join("\n");
  const [p] = parseCatalogCsv(csv);
  assert.equal(p.categoria, "Hogar");
  assert.equal(p.descripcion, "Desc");
  assert.equal(p.tamano, "5 cm");
});

test("parseCatalogCsv conserva emojis, ñ y tildes en la descripción", () => {
  const csv = [HEADER, row({ descripcion: '"Pequeño soporte, útil 🎉"' })].join("\n");
  assert.equal(parseCatalogCsv(csv)[0].descripcion, "Pequeño soporte, útil 🎉");
});

test("parseCatalogCsv con solo cabeceras devuelve []", () => {
  assert.deepEqual(parseCatalogCsv(HEADER + "\n"), []);
});

test("filterPieces busca sin distinguir mayúsculas ni tildes en nombre y descripción", () => {
  const csv = [HEADER, row({ id: "1", nombre: "Soporte móvil" }),
    row({ id: "2", nombre: "Llavero", descripcion: "Con forma de ÁRBOL" })].join("\n");
  const pieces = parseCatalogCsv(csv);
  assert.deepEqual(filterPieces(pieces, { query: "MOVIL" }).map((p) => p.id), ["1"]);
  assert.deepEqual(filterPieces(pieces, { query: "arbol" }).map((p) => p.id), ["2"]);
});

test("filterPieces filtra por categoría exacta y combina con la búsqueda", () => {
  const csv = [HEADER, row({ id: "1", nombre: "A", categoria: "Hogar" }),
    row({ id: "2", nombre: "A", categoria: "Oficina" }),
    row({ id: "3", nombre: "B", categoria: "Hogar" })].join("\n");
  const pieces = parseCatalogCsv(csv);
  assert.deepEqual(filterPieces(pieces, { category: "Hogar" }).map((p) => p.id), ["1", "3"]);
  assert.deepEqual(filterPieces(pieces, { category: "Hogar", query: "a" }).map((p) => p.id), ["1"]);
});

test("categoriesOf devuelve las categorías sin repetir, en orden alfabético", () => {
  const csv = [HEADER, row({ id: "1", categoria: "Oficina" }), row({ id: "2", categoria: "Hogar" }),
    row({ id: "3", categoria: "Oficina" })].join("\n");
  assert.deepEqual(categoriesOf(parseCatalogCsv(csv)), ["Hogar", "Oficina"]);
});
